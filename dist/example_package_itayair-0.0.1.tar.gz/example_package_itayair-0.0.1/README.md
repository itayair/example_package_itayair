# 'example_package_itayair'

The 'example_package_itayair' is a simple testing example to understand the basics of developing your first Python package.