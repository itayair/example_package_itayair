# 'example_package_itayair'

The 'example_package_itayair2' is a simple testing example to understand the basics of developing your first Python package.